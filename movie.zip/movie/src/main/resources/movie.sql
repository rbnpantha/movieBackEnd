create database movieDB;

use movieDB;

create table movie (
id int,
title varchar(50),
director varchar(50)
)

insert into movie values (
01,
"Life is Beautiful",
"Run Van Nesteroa"
)